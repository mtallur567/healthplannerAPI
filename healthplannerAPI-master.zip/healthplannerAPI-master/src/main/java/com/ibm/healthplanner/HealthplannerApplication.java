package com.ibm.healthplanner;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HealthplannerApplication {

	public static void main(String[] args) {
		SpringApplication.run(HealthplannerApplication.class, args);
	}

}
